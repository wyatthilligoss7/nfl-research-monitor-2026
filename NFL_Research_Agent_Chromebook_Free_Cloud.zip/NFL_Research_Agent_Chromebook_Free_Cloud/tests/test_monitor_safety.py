from datetime import date, datetime, timedelta, timezone
import os

import pandas as pd

from agent.health import freshness_report
from agent.monitor import scheduled_games
from agent.validate import validate


def test_recent_team_schema(tmp_path, monkeypatch):
    df = pd.DataFrame([{'player_id': 'p1', 'recent_team': 'WAS', 'season': 2026, 'week': 3}])
    (tmp_path / 'player_stats.parquet').write_bytes(b'test placeholder')
    monkeypatch.setattr(pd, 'read_parquet', lambda _: df)
    assert validate(tmp_path)['checks']['player_stats']['status'] == 'ok'


def test_utc_monday_before_kickoff_appears():
    schedule = pd.DataFrame([{'season': 2026, 'week': 6, 'gameday': '2026-10-19',
                              'gametime': '20:15', 'away_team': 'WAS', 'home_team': 'SF',
                              'game_type': 'REG'}])
    before = datetime(2026, 10, 20, 0, 0, tzinfo=timezone.utc)
    after = datetime(2026, 10, 20, 0, 20, tzinfo=timezone.utc)
    assert len(scheduled_games(schedule, date(2026, 10, 19), as_of=before)) == 1
    assert len(scheduled_games(schedule, date(2026, 10, 19), as_of=after)) == 0


def test_stale_or_missing_feed_not_labeled_current(tmp_path):
    assert freshness_report(tmp_path)['ready_for_current_research'] is False
    for name in ('schedules', 'player_stats', 'weekly_rosters'):
        (tmp_path / f'{name}.parquet').write_text('test fixture')
    assert freshness_report(tmp_path)['ready_for_current_research'] is True
    old = datetime.now(timezone.utc) - timedelta(days=4)
    target = tmp_path / 'player_stats.parquet'
    os.utime(target, (old.timestamp(), old.timestamp()))
    assert freshness_report(tmp_path)['feeds']['player_stats']['status'] == 'STALE'
