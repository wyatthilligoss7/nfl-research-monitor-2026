from agent.validate import TEAM_CODES, standardized_team


def test_32_teams():
    assert len(TEAM_CODES) == 32


def test_canonical_teams():
    assert standardized_team('JAC') == 'JAX'
    assert standardized_team('LA') == 'LAR'
    assert standardized_team('WSH') == 'WAS'
    assert standardized_team('CHI') == 'CHI'

import json
from datetime import date, datetime, timezone
import pandas as pd
from agent.game_research import assemble_game_report, usage_changes
from agent.monitor import scheduled_games
from agent.status import read_statuses


def test_asof_later_game_never_leaks():
    stats = pd.DataFrame([
        {"season":2026,"week":4,"season_type":"REG","team":"WAS","player_id":"abc","player_display_name":"A Player","position":"WR","targets":4,"receiving_yards":30},
        {"season":2026,"week":5,"season_type":"REG","team":"WAS","player_id":"abc","player_display_name":"A Player","position":"WR","targets":7,"receiving_yards":75},
        {"season":2026,"week":6,"season_type":"REG","team":"WAS","player_id":"abc","player_display_name":"A Player","position":"WR","targets":25,"receiving_yards":250},
    ])
    roster = pd.DataFrame([{"season":2026,"team":"WAS","gsis_id":"abc"}])
    report = assemble_game_report({"player_stats":stats, "rosters":roster}, 2026, 6, "WAS", "SF")
    row = report["player_usage"]["WAS"][0]
    assert row["games_observed"] == 2
    assert row["per_game_averages"]["targets"] == 5.5
    assert row["on_loaded_roster"] is True


def test_move_to_other_team_does_not_carry_old_team():
    stats = pd.DataFrame([
        {"season":2026,"week":2,"season_type":"REG","team":"WAS","player_id":"xyz","player_display_name":"Moved","position":"WR","targets":5},
        {"season":2026,"week":3,"season_type":"REG","team":"SF","player_id":"xyz","player_display_name":"Moved","position":"WR","targets":3},
    ])
    roster = pd.DataFrame([{"season":2026,"team":"SF","gsis_id":"xyz"}])
    report = assemble_game_report({"player_stats":stats, "rosters":roster}, 2026, 6, "WAS", "SF")
    assert report["player_usage"]["WAS"][0]["on_loaded_roster"] is False
    assert report["player_usage"]["SF"][0]["on_loaded_roster"] is True


def test_statuses_respect_capture_as_of(tmp_path):
    p = tmp_path / "st.json"
    p.write_text(json.dumps([{"season":2026,"week":6,"team":"SF","player":"Example Player",
        "status":"QUESTIONABLE","observed_utc":"2026-10-19T13:00:00Z","source_url":"https://www.nfl.com"},
        {"season":2026,"week":6,"team":"SF","player":"Example Player",
        "status":"OUT","observed_utc":"2026-10-19T19:00:00Z","source_url":"https://www.nfl.com"}]))
    rec = read_statuses(p, datetime(2026,10,19,16,tzinfo=timezone.utc))
    assert len(rec) == 1 and rec[0]["status"] == "QUESTIONABLE"


def test_schedule_only_upcoming():
    df = pd.DataFrame([
        {"season":2026,"week":5,"gameday":"2026-10-11","away_team":"WAS","home_team":"SF","game_type":"REG"},
        {"season":2026,"week":6,"gameday":"2026-10-19","away_team":"WAS","home_team":"SF","game_type":"REG"},
        {"season":2026,"week":12,"gameday":"2026-11-20","away_team":"NYJ","home_team":"NE","game_type":"REG"},
    ])
    result = scheduled_games(df, date(2026,10,19))
    assert len(result) == 1 and result[0]["week"] == 6


def test_usage_change_requires_history():
    assert usage_changes(pd.DataFrame({"week":[1,2,3,4],"targets":[1,2,10,10]})) == []
    detected = usage_changes(pd.DataFrame({"week":[1,2,3,4,5],"targets":[2,2,2,8,8]}))
    assert detected[0]["direction"] == "up"


def test_latest_week_roster_wins_over_season_snapshot():
    stats = pd.DataFrame([
        {"season":2026,"week":3,"season_type":"REG","team":"WAS","player_id":"xy","player_display_name":"A Player","position":"WR","targets":5},
        {"season":2026,"week":5,"season_type":"REG","team":"SF","player_id":"xy","player_display_name":"A Player","position":"WR","targets":3},
    ])
    season_roster = pd.DataFrame([{"season":2026,"team":"WAS","gsis_id":"xy"}])
    weekly = pd.DataFrame([
        {"season":2026,"week":3,"team":"WAS","gsis_id":"xy"},
        {"season":2026,"week":5,"team":"SF","gsis_id":"xy"},
    ])
    report = assemble_game_report({"player_stats":stats, "rosters":season_roster,
                                  "weekly_rosters":weekly}, 2026, 6, "WAS", "SF")
    assert report["roster_source"] == "weekly"
    assert report["player_usage"]["WAS"][0]["on_loaded_roster"] is False
    assert report["player_usage"]["SF"][0]["on_loaded_roster"] is True


def test_multiple_same_week_teams_marked_unknown():
    stats = pd.DataFrame([
        {"season":2026,"week":3,"season_type":"REG","team":"WAS","player_id":"xy","player_display_name":"A Player","position":"WR","targets":4},
    ])
    weekly = pd.DataFrame([
        {"season":2026,"week":5,"team":"WAS","gsis_id":"xy"},
        {"season":2026,"week":5,"team":"SF","gsis_id":"xy"},
    ])
    report = assemble_game_report({"player_stats":stats, "weekly_rosters":weekly}, 2026, 6, "WAS", "SF")
    assert report["player_usage"]["WAS"][0]["on_loaded_roster"] is None
    assert any("Ambiguous" in w for w in report["warnings"])
