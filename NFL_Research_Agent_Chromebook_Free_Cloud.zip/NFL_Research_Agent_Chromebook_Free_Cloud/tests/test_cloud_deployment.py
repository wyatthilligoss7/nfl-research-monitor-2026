"""Offline checks for the GitHub Actions + free Streamlit design."""
from pathlib import Path
import json
import os
import pytest

from agent.collect import configured_seasons
from scripts.publish_summary import publish


def test_workflow_includes_manual_and_scheduled_runs():
    workflow = Path('.github/workflows/nfl-refresh.yml').read_text()
    assert 'workflow_dispatch:' in workflow
    assert "cron: '17 2,8,14,20 * * *'" in workflow
    assert 'contents: write' in workflow


def test_seasons_env_override(monkeypatch):
    monkeypatch.setenv('NFL_AGENT_SEASONS', '2026,2025,2026')
    assert configured_seasons() == [2025, 2026]
    monkeypatch.setenv('NFL_AGENT_SEASONS', 'not a year')
    with pytest.raises(ValueError):
        configured_seasons()


def test_repo_manifest_has_no_credentials(tmp_path):
    path = publish(tmp_path, 'example/nfl-research-monitor-2026')
    obj = json.loads(path.read_text())
    assert obj['github_repository'] == 'example/nfl-research-monitor-2026'
    assert not any('token' in key or 'secret' in key for key in obj)
    with pytest.raises(ValueError):
        publish(tmp_path, 'evil.com/../oops')


def test_gitignore_avoids_uploading_full_downloads():
    text = Path('.gitignore').read_text()
    assert '/data/*.parquet' in text
    assert '.streamlit/secrets.toml' in text
