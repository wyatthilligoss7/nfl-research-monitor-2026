"""Publish the public repository slug for the free hosted read-only dashboard.

This tool intentionally does not store tokens, account credentials, or raw parquet.
"""
from __future__ import annotations
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path


def publish(data_dir: Path, repository: str | None) -> Path:
    data_dir = Path(data_dir)
    data_dir.mkdir(parents=True, exist_ok=True)
    repo = repository or ''
    if repo and not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repo):
        raise ValueError('Repository must be owner/name')
    result = {
        'github_repository': repo or None,
        'generated_utc': datetime.now(timezone.utc).isoformat(),
        'dashboard_visibility': 'public-repository' if repo else 'local-preview',
    }
    dest = data_dir / 'repo.json'
    temp = data_dir / 'repo.json.tmp'
    temp.write_text(json.dumps(result, indent=2), encoding='utf-8')
    temp.replace(dest)
    return dest


if __name__ == '__main__':
    print(publish(Path(os.getenv('NFL_AGENT_DATA_DIR', 'data')), os.getenv('GITHUB_REPOSITORY')))
