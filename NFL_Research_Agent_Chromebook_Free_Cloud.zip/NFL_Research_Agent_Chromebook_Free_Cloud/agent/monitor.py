"""Generate pregame research reports from prior game outcomes and roster snapshots.

Does not compute prospective player props, odds, or wagers.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone, timedelta, time
from zoneinfo import ZoneInfo
from pathlib import Path

import pandas as pd

from .game_research import from_disk, write_report
from .validate import TEAM_CODES, standardized_team


def scheduled_games(frame: pd.DataFrame, today, days: int = 7,
                    as_of: datetime | None = None) -> list[dict]:
    if frame is None or frame.empty:
        return []
    needed = {'season', 'week', 'gameday', 'away_team', 'home_team'}
    if not needed.issubset(frame.columns):
        return []
    df = frame.copy()
    df['gameday'] = pd.to_datetime(df.gameday, errors='coerce').dt.date
    df = df[(df.gameday >= today) & (df.gameday <= today + timedelta(days=days))]
    if 'game_type' in df:
        df = df[df.game_type.isin(['REG', 'WC', 'DIV', 'CON', 'SB'])]
    results = []
    for _, r in df.sort_values(['gameday', 'week']).iterrows():
        away = standardized_team(r.away_team)
        home = standardized_team(r.home_team)
        if away not in TEAM_CODES or home not in TEAM_CODES or away == home:
            continue
        kickoff = None
        clock = r.get('gametime')
        if pd.notna(clock):
            try:
                h, m = (int(v) for v in str(clock).split(':')[:2])
                kickoff = datetime.combine(r.gameday, time(h, m), tzinfo=ZoneInfo('America/New_York')).astimezone(timezone.utc)
            except (ValueError, TypeError):
                kickoff = None
        if as_of is not None and kickoff is not None and as_of >= kickoff:
            continue
        results.append({'season': int(r.season), 'week': int(r.week),
                        'away': away, 'home': home, 'date': r.gameday.isoformat(),
                        'game_id': str(r.get('game_id', '')),
                        'kickoff_utc': kickoff.isoformat() if kickoff else None})
    return results


def refresh_watchlist(data_dir: Path, statuses_file: Path | None = None,
                      as_of: datetime | None = None, days: int = 7) -> dict:
    as_of = (as_of or datetime.now(timezone.utc)).astimezone(timezone.utc)
    folder = Path(data_dir)
    schedule_path = folder / 'schedules.parquet'
    result = {'generated_utc': as_of.isoformat(), 'games': [], 'warnings': []}
    if not schedule_path.exists():
        result['warnings'].append('Schedules not loaded; game reports cannot be built')
    else:
        eastern_date = as_of.astimezone(ZoneInfo('America/New_York')).date()
        games = scheduled_games(pd.read_parquet(schedule_path), eastern_date, days, as_of)
        if not games:
            result['warnings'].append('No upcoming fixtures identified in window')
        for game in games:
            report = from_disk(folder, game['season'], game['week'],
                               game['away'], game['home'], statuses_file, as_of)
            slug = f"game_{game['season']}_{game['week']}_{game['away']}_{game['home']}"
            file = write_report(folder / 'game_reports', report, slug)
            result['games'].append({**game, 'file': str(file.relative_to(folder)),
                                    'warnings': len(report['warnings'])})
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / 'game_watchlist.json'
    tmp = target.with_suffix('.json.tmp')
    tmp.write_text(json.dumps(result, indent=2), encoding='utf-8')
    tmp.replace(target)
    return result


if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser(description='Build NFL game research reports from past observations')
    p.add_argument('--data-dir', default='data')
    p.add_argument('--status-file', default='fixtures/statuses.json')
    args = p.parse_args()
    print(json.dumps(refresh_watchlist(Path(args.data_dir), Path(args.status_file)), indent=2))
