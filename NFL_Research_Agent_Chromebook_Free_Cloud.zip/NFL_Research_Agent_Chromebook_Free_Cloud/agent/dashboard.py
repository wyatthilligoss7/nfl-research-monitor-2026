"""Research dashboard for observed NFL player and team performance."""
import json
import os
from pathlib import Path

import pandas as pd
import streamlit as st

D = Path(os.getenv('NFL_AGENT_DATA_DIR', './data'))
st.set_page_config(page_title='NFL 2026 Research Monitor', layout='wide')
st.title('NFL 2026 Research Monitor')
st.caption('Public NFL team/player history, roster snapshots and source-aware injury reports. No betting lines or predictions.')
mode = st.radio('Explore', ['Upcoming games', 'Past player usage', 'Data explorer', 'Data quality'], horizontal=True)


def read_json(path):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (ValueError, OSError):
        return None


if mode == 'Data quality':
    for key in ('health', 'refresh_status', 'source_checks', 'game_watchlist'):
        report = read_json(D / f'{key}.json')
        if report is None:
            st.warning(f'{key}.json missing: run the collector on an internet-connected host')
        else:
            with st.expander(key.replace('_', ' ').title(), expanded=(key == 'health')):
                st.json(report)

elif mode in ('Upcoming games', 'Past player usage'):
    index = read_json(D / 'game_watchlist.json') or {}
    choices = {f"{g['date']}: {g['away']} at {g['home']}": g for g in index.get('games', [])}
    if not choices:
        st.info('No research reports yet. Run `python -m agent.worker --once` on an internet-connected computer.')
        st.stop()
    selected = st.selectbox('Game', list(choices))
    report = read_json(D / choices[selected]['file'])
    if not report:
        st.warning('This game report was not found')
        st.stop()
    st.caption(f"Compiled {report['created_utc']}, source cutoff: {report['source_cutoff']}")
    for warning in report.get('warnings', []):
        st.warning(warning)
    if mode == 'Upcoming games':
        st.subheader('Previous observed team performance')
        rows = [{'Team': team, 'Observed games': x['observed_games'], **x['per_game_averages']}
                for team, x in report.get('team_form', {}).items()]
        if rows:
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
        st.subheader('Verified published status records')
        available = report.get('reported_availability', [])
        if available:
            st.dataframe(pd.DataFrame(available), use_container_width=True, hide_index=True)
        else:
            st.info('No verified status records in the provided file; status is unknown, not assumed healthy')
    else:
        team = st.selectbox('Team', [report['away'], report['home']])
        entries = report.get('player_usage', {}).get(team, [])
        if entries:
            rows = [{'Player': p['player'], 'Position': p['position'], 'Observed games': p['games_observed'],
                     'Roster snapshot match': p['on_loaded_roster'], **p['per_game_averages']}
                    for p in entries]
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
            changes = [{'Player': p['player'], **change} for p in entries
                       for change in p['observed_usage_changes']]
            if changes:
                st.subheader('Observed usage changes')
                st.dataframe(pd.DataFrame(changes), use_container_width=True, hide_index=True)
        else:
            st.info('Historical player stats unavailable for this team and prior-week cutoff')

else:
    names = {'Current rosters': 'rosters', 'Weekly rosters': 'weekly_rosters',
             'Player statistics': 'player_stats', 'Team statistics': 'team_stats',
             'Schedules': 'schedules', 'Snap counts': 'snap_counts'}
    selected = st.selectbox('Dataset', list(names))
    target = D / f"{names[selected]}.parquet"
    if not target.exists():
        st.warning('Dataset not yet loaded')
        st.stop()
    frame = pd.read_parquet(target)
    team_col = next((x for x in ('team', 'recent_team') if x in frame), None)
    if team_col:
        teams = sorted(frame[team_col].dropna().astype(str).unique())
        team = st.selectbox('Team', ['All'] + teams)
        if team != 'All':
            frame = frame[frame[team_col].eq(team)]
    if 'season' in frame:
        years = sorted(frame.season.dropna().unique(), reverse=True)
        year = st.selectbox('Season', ['All'] + list(years))
        if year != 'All':
            frame = frame[frame.season.eq(year)]
    st.caption(f'{len(frame):,} matching records')
    st.dataframe(frame.head(300), use_container_width=True, hide_index=True)
