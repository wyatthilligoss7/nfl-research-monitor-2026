"""Source integrity checks for NFL datasets; no sports-market functions."""
from pathlib import Path
import json
from datetime import datetime, timezone
import pandas as pd

TEAM_CODES = set('ARI ATL BAL BUF CAR CHI CIN CLE DAL DEN DET GB HOU IND JAX KC LAC LAR LV MIA MIN NE NO NYG NYJ PHI PIT SEA SF TB TEN WAS'.split())
ALIASES = {'LA': 'LAR', 'JAC': 'JAX', 'WSH': 'WAS', 'OAK': 'LV', 'SD': 'LAC', 'STL': 'LAR'}


def standardized_team(value):
    if pd.isna(value):
        return None
    team = str(value).upper().strip()
    return ALIASES.get(team, team)


def validate(data_dir):
    data_dir = Path(data_dir)
    diagnostics = {'checked_utc': datetime.now(timezone.utc).isoformat(), 'checks': {}}
    for key, required in {
        'player_stats': ['player_id', 'season', 'week'],
        'rosters': ['team'],
        'schedules': ['home_team', 'away_team', 'week'],
    }.items():
        path = data_dir / f'{key}.parquet'
        if not path.exists():
            diagnostics['checks'][key] = {'status': 'missing'}
            continue
        data = pd.read_parquet(path)
        missing_cols = [col for col in required if col not in data.columns]
        if key == 'player_stats' and not ({'team', 'recent_team'} & set(data.columns)):
            missing_cols.append('team OR recent_team')
        entry = {'status': 'ok' if not missing_cols else 'invalid_schema',
                 'rows': len(data), 'missing_columns': missing_cols}
        team_col = 'team' if 'team' in data else 'recent_team' if 'recent_team' in data else None
        if team_col:
            teams = {standardized_team(x) for x in data[team_col].dropna().unique()}
            entry['team_count'] = len(teams & TEAM_CODES)
            entry['unrecognized_team_codes'] = sorted(teams - TEAM_CODES)
        diagnostics['checks'][key] = entry
    (data_dir / 'source_checks.json').write_text(json.dumps(diagnostics, indent=2))
    return diagnostics
