"""NFL performance research agent (no wagering integration)."""
