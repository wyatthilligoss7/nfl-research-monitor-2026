"""Retrieve 2023-present NFL datasets through the public nflreadpy interface.

Datasets are saved atomically and individually, so a failed API download
cannot silently overwrite a successful prior refresh. Injury data is intentionally
NOT pulled from nflverse: its historical feed is documented as incomplete for
recent seasons. See README for future official-report integration.
"""
from __future__ import annotations

import argparse
import json
import os
from datetime import datetime, timezone
from pathlib import Path

DATA = Path(os.getenv('NFL_AGENT_DATA_DIR', './data'))
SEASONS = [2023, 2024, 2025, 2026]


def configured_seasons() -> list[int]:
    """Read selected seasons from the runner environment; default keeps V4 history."""
    override = os.getenv('NFL_AGENT_SEASONS', '').strip()
    if not override:
        return SEASONS
    years = sorted({int(item.strip()) for item in override.split(',') if item.strip()})
    if not years or any(year < 1999 or year > 2100 for year in years):
        raise ValueError('NFL_AGENT_SEASONS must contain reasonable season years')
    return years


def refresh(data_dir: Path = DATA, seasons: list[int] | None = None) -> dict:
    import nflreadpy as nfl

    data_dir = Path(data_dir)
    data_dir.mkdir(parents=True, exist_ok=True)
    years = seasons if seasons is not None else configured_seasons()
    sources = {
        'player_stats': lambda: nfl.load_player_stats(years, summary_level='week'),
        'team_stats': lambda: nfl.load_team_stats(years, summary_level='week'),
        'schedules': lambda: nfl.load_schedules(years),
        'rosters': lambda: nfl.load_rosters([years[-1]]),
        'weekly_rosters': lambda: nfl.load_rosters_weekly([years[-1]]),
        'depth_charts': lambda: nfl.load_depth_charts([years[-1]]),
        'snap_counts': lambda: nfl.load_snap_counts(years),
    }
    report = {'refresh_started_utc': datetime.now(timezone.utc).isoformat(),
              'seasons': years, 'datasets': {}}
    for name, loader in sources.items():
        try:
            frame = loader()  # Polars DataFrame supplied by nflreadpy
            path = data_dir / f'{name}.parquet'
            tmp = data_dir / f'{name}.parquet.tmp'
            frame.write_parquet(tmp)
            os.replace(tmp, path)
            report['datasets'][name] = {'status': 'ok', 'rows': frame.height,
                                        'refreshed_utc': datetime.now(timezone.utc).isoformat()}
        except Exception as exc:
            report['datasets'][name] = {'status': 'ERROR', 'reason': str(exc)[:250]}
    report['refresh_finished_utc'] = datetime.now(timezone.utc).isoformat()
    (data_dir / 'refresh_status.json').write_text(json.dumps(report, indent=2))
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-dir', default=str(DATA))
    args = parser.parse_args()
    print(json.dumps(refresh(Path(args.data_dir)), indent=2))
