"""Continuously refresh public NFL research datasets on a hosted machine."""
import json
import logging
import os
import time
from pathlib import Path

from .collect import refresh
from .validate import validate
from .monitor import refresh_watchlist
from .health import freshness_report, save_health

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
DATA_DIR = Path(os.getenv('NFL_AGENT_DATA_DIR', './data'))
STATUS_PATH = Path(os.getenv('NFL_AGENT_STATUS_FILE', './fixtures/statuses.json'))
SLEEP_SECONDS = max(3600, int(os.getenv('NFL_AGENT_REFRESH_SECONDS', '21600')))


def cycle():
    sources = refresh(DATA_DIR)
    logging.info('Datasets: %s', json.dumps(sources['datasets']))
    checks = validate(DATA_DIR)
    logging.info('Validation: %s', json.dumps(checks['checks']))
    health = freshness_report(DATA_DIR)
    save_health(DATA_DIR, health)
    if not health['ready_for_current_research']:
        logging.warning('Missing or stale source data; dashboard will mark these limitations')
    watchlist = refresh_watchlist(DATA_DIR, STATUS_PATH)
    logging.info('Upcoming research reports: %s', len(watchlist['games']))


def run():
    while True:
        try:
            cycle()
        except Exception:
            logging.exception('Research refresh cycle failed; retrying later')
        time.sleep(SLEEP_SECONDS)


if __name__ == '__main__':
    import sys
    if '--once' in sys.argv:
        cycle()
    else:
        run()
