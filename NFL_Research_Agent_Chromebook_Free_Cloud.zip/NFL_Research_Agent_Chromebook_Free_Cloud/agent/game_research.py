"""Historical football-usage notebook and game-context report.

Reports summarize observed usage, with no sportsbook lines or wagering advice.
All input statistics are strictly from games before the target game week.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd

from .status import read_statuses
from .validate import standardized_team

USAGE_METRICS = (
    "attempts", "completions", "passing_yards", "passing_tds",
    "rushing_attempts", "rushing_yards", "receptions", "targets",
    "receiving_yards", "receiving_tds", "snap_pct", "offense_pct",
)
NAME_FIELDS = ("player_display_name", "player_name", "full_name")


def _format_num(value):
    try:
        return round(float(value), 1) if pd.notna(value) else None
    except (TypeError, ValueError):
        return None


def _prior_games(df: pd.DataFrame | None, season: int, week: int) -> pd.DataFrame:
    if df is None or df.empty or not {"season", "week"}.issubset(df.columns):
        return pd.DataFrame()
    x = df.copy()
    x["season"] = pd.to_numeric(x["season"], errors="coerce")
    x["week"] = pd.to_numeric(x["week"], errors="coerce")
    x = x[x.season.eq(season) & x.week.lt(week)].copy()
    if "season_type" in x:
        x = x[x.season_type.isin(["REG", "Regular Season"])].copy()
    return x


def usage_changes(games: pd.DataFrame) -> list[dict]:
    """Observed change in workload; requires >=5 prior games and sample sufficiency."""
    if games.empty or "week" not in games.columns:
        return []
    out = []
    for metric, min_difference in (("targets", 2), ("rushing_attempts", 4), ("attempts", 5)):
        if metric not in games:
            continue
        ordered = games.sort_values("week")
        values = pd.to_numeric(ordered[metric], errors="coerce").dropna()
        if len(values) < 5:
            continue
        previous = float(values.iloc[-5:-2].mean())
        recent = float(values.iloc[-2:].mean())
        if abs(recent - previous) >= min_difference and (previous == 0 or abs(recent / previous - 1) >= 0.35):
            out.append({"metric": metric, "previous_three_avg": round(previous, 1),
                        "recent_two_avg": round(recent, 1), "direction": "up" if recent > previous else "down"})
    return out


def _find_current_roster_ids(rosters: pd.DataFrame | None,
                             weekly_rosters: pd.DataFrame | None,
                             season: int, week: int):
    """Use latest week-specific roster (preferred), otherwise season snapshot.

    Return (team IDs, ambiguous IDs, source label). Multiple team memberships at
    the same effective time are *unknown*, never assumed active on both rosters.
    """
    roster = weekly_rosters
    source = "weekly"
    if roster is None or roster.empty or not {"team", "week"}.issubset(roster.columns):
        roster = rosters
        source = "season"
    if roster is None or roster.empty or "team" not in roster.columns:
        return None, set(), "missing"
    id_col = next((c for c in ("gsis_id", "player_id") if c in roster.columns), None)
    if id_col is None:
        return None, set(), "missing player ID"
    x = roster.copy()
    if "season" in x.columns:
        x = x[pd.to_numeric(x.season, errors="coerce").eq(season)]
    if source == "weekly":
        x["week"] = pd.to_numeric(x["week"], errors="coerce")
        x = x[x.week.lt(week)]
        if x.empty:
            return _find_current_roster_ids(rosters, None, season, week)
        latest_week = x.groupby(id_col)["week"].transform('max')
        x = x[x.week.eq(latest_week)]
    x["canonical_team"] = x.team.map(standardized_team)
    x[id_col] = x[id_col].astype(str)
    all_teams = x.groupby(id_col).canonical_team.agg(lambda c: set(c.dropna()))
    ambiguous = {id_ for id_, teamset in all_teams.items() if len(teamset) != 1}
    ids = {team: set(g[id_col]) - ambiguous for team, g in x.groupby("canonical_team")}
    return ids, ambiguous, source


def assemble_game_report(frames: dict[str, pd.DataFrame], season: int, week: int,
                         away: str, home: str, statuses: list[dict] | None = None,
                         as_of: datetime | None = None) -> dict:
    """Assemble strictly pregame historical context from locally supplied dataframes.

    Caller should fetch stats and roster files before invoking. If a current
    roster cannot be established, roster status is labeled unverified.
    """
    away, home = standardized_team(away), standardized_team(home)
    if not away or not home or home == away:
        raise ValueError("Select two different valid team codes")
    as_of = (as_of or datetime.now(timezone.utc)).astimezone(timezone.utc)
    report = {"season": int(season), "week": int(week), "away": away, "home": home,
              "created_utc": as_of.isoformat(), "source_cutoff": f"Prior to season {season}, week {week}",
              "team_form": {}, "player_usage": {}, "reported_availability": [], "warnings": []}

    team_df = _prior_games(frames.get("team_stats"), season, week)
    if 'team' not in team_df.columns and 'recent_team' in team_df.columns:
        team_df['team'] = team_df['recent_team']
    if "team" in team_df.columns:
        team_df["canonical_team"] = team_df.team.map(standardized_team)
    for team in (away, home):
        team_games = team_df[team_df.canonical_team.eq(team)] if "canonical_team" in team_df else pd.DataFrame()
        metrics = {}
        for field in ("passing_yards", "rushing_yards", "attempts", "rushing_attempts", "passing_tds"):
            if field in team_games:
                mean = pd.to_numeric(team_games[field], errors="coerce").mean()
                metrics[field] = _format_num(mean)
        report["team_form"][team] = {"observed_games": int(len(team_games)), "per_game_averages": metrics}

    report["reported_availability"] = [
        x for x in (statuses or []) if int(x["season"]) == season and int(x["week"]) == week
        and standardized_team(x["team"]) in (away, home)
    ]
    player_df = _prior_games(frames.get("player_stats"), season, week)
    if 'team' not in player_df.columns and 'recent_team' in player_df.columns:
        player_df['team'] = player_df['recent_team']
    if 'team' in player_df.columns and 'recent_team' in player_df.columns:
        player_df['team'] = player_df['team'].fillna(player_df['recent_team'])
    roster_ids, ambiguous_ids, roster_source = _find_current_roster_ids(
        frames.get("rosters"), frames.get("weekly_rosters"), season, week)
    report["roster_source"] = roster_source
    if not {"player_id", "team"}.issubset(player_df.columns):
        report["warnings"].append("Player stats not loaded; no player-level analysis available")
        report["warnings"].append("Published injury designations are not confirmation of the final active/inactive list")
        return report
    player_df["canonical_team"] = player_df.team.map(standardized_team)
    player_df = player_df[player_df.canonical_team.isin([away, home])].copy()
    if roster_ids is None:
        report["warnings"].append("Roster identities not verified; historical teams do not confirm current availability")
    elif roster_source == "season":
        report["warnings"].append("Season roster used because no weekly roster was available; transaction status may be stale")
    if ambiguous_ids:
        report["warnings"].append(f"Ambiguous team membership for {len(ambiguous_ids)} player IDs; marked unverified")
    for team in (away, home):
        summaries = []
        x = player_df[player_df.canonical_team.eq(team)]
        for player_id, games in x.groupby("player_id", dropna=True):
            games = games.sort_values("week")
            person = games.iloc[-1]
            name = next((str(person[n]) for n in NAME_FIELDS if n in person and pd.notna(person[n])), str(player_id))
            metrics = {m: _format_num(pd.to_numeric(games[m], errors="coerce").mean())
                       for m in USAGE_METRICS if m in games}
            is_on_roster = (None if roster_ids is None or str(player_id) in ambiguous_ids
                            else str(player_id) in roster_ids.get(team, set()))
            summaries.append({"player_id": str(player_id), "player": name,
                              "position": str(person.get("position", "Unknown")), "games_observed": int(len(games)),
                              "last_observed_week": int(games.week.max()),
                              "on_loaded_roster": is_on_roster, "per_game_averages": metrics,
                              "observed_usage_changes": usage_changes(games)})
        summaries.sort(key=lambda p: (sum(p["per_game_averages"].get(key, 0) or 0 for key in
                                          ("passing_yards", "rushing_yards", "receiving_yards"))), reverse=True)
        report["player_usage"][team] = summaries
    report["warnings"].append("Published injury designations are not confirmation of the final active/inactive list")
    return report


def from_disk(data_dir: Path, season: int, week: int, away: str, home: str,
              statuses_file: Path | None = None, as_of: datetime | None = None) -> dict:
    from pathlib import Path
    folder = Path(data_dir)
    frames = {}
    for key in ("team_stats", "player_stats", "rosters", "weekly_rosters"):
        path = folder / f"{key}.parquet"
        if path.exists():
            frames[key] = pd.read_parquet(path)
    statuses = read_statuses(statuses_file, as_of=as_of) if statuses_file else []
    report = assemble_game_report(frames, season, week, away, home, statuses, as_of)
    if not (folder / "player_stats.parquet").exists():
        report["warnings"].append("No player_stats.parquet file on disk")
    return report


def write_report(data_dir: Path, report: dict, slug: str = "tonight_game_context") -> Path:
    target = Path(data_dir) / f"{slug}.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(".json.tmp")
    temp.write_text(json.dumps(report, indent=2), encoding="utf-8")
    temp.replace(target)
    return target
