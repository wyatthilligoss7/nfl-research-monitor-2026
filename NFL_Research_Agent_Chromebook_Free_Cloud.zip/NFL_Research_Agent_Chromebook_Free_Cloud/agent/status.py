"""Auditable, time-aware official injury-status overlay.

This module does not scrape websites. Human-verified game reports can be stored
as JSON with a URL and capture timestamp. Unconfirmed entries cannot be
silently upgraded to active on gameday.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

VALID_STATUSES = {"OUT", "DOUBTFUL", "QUESTIONABLE", "UNSPECIFIED", "CLEARED"}


def utc_timestamp(value: str) -> datetime:
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if result.tzinfo is None:
        raise ValueError("Source timestamps must include a timezone")
    return result.astimezone(timezone.utc)


def read_statuses(file_path: Path, as_of: datetime | None = None) -> list[dict]:
    file_path = Path(file_path)
    if not file_path.exists():
        return []
    as_of = (as_of or datetime.now(timezone.utc)).astimezone(timezone.utc)
    records = json.loads(file_path.read_text(encoding="utf-8"))
    if not isinstance(records, list):
        raise ValueError("Status input must be an array")
    latest: dict[tuple, dict] = {}
    for record in records:
        fields = ("season", "week", "team", "player", "status", "observed_utc", "source_url")
        if any(not record.get(key) and record.get(key) != 0 for key in fields):
            raise ValueError(f"Status record is missing a mandatory field: {record}")
        record = dict(record)
        record["status"] = record["status"].upper()
        if record["status"] not in VALID_STATUSES:
            raise ValueError(f"Unknown status {record['status']}")
        t = utc_timestamp(record["observed_utc"])
        if t > as_of:
            continue  # Avoid contaminating historical snapshots with later reports.
        k = (int(record["season"]), int(record["week"]), record["team"], record["player"].casefold())
        if k not in latest or utc_timestamp(latest[k]["observed_utc"]) < t:
            latest[k] = record
    return sorted(latest.values(), key=lambda r: (r["team"], r["player"]))
