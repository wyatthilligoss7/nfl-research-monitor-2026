"""Operational and data freshness checks for an independently hosted agent."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

# A stale feed is explicitly visible instead of being treated as current.
MAX_AGE_HOURS = {'schedules': 12, 'rosters': 36, 'weekly_rosters': 36,
                 'player_stats': 36, 'team_stats': 36, 'snap_counts': 48,
                 'depth_charts': 48}


def _read_json(path: Path):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}


def freshness_report(data_dir: Path, now: datetime | None = None) -> dict:
    data_dir = Path(data_dir)
    now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    ingested = _read_json(data_dir / 'refresh_status.json')
    datasets = ingested.get('datasets', {})
    checked = {}
    for name, threshold in MAX_AGE_HOURS.items():
        file = data_dir / f'{name}.parquet'
        datum = datasets.get(name, {})
        if not file.exists():
            checked[name] = {'status': 'MISSING', 'age_hours': None, 'last_refresh': None}
            continue
        # Actual parquet modification time covers previously successful refreshes
        # even if the current fetch failed and refresh_status.json was overwritten.
        age = max(0.0, (now.timestamp() - file.stat().st_mtime) / 3600)
        checked[name] = {'status': 'STALE' if age > threshold else 'AVAILABLE',
                         'age_hours': round(age, 2),
                         'last_refresh': datetime.fromtimestamp(file.stat().st_mtime,
                                                              timezone.utc).isoformat(),
                         'latest_attempt': datum.get('status', 'UNKNOWN')}
    return {'checked_utc': now.isoformat(), 'feeds': checked,
            'ready_for_current_research': all(
                checked[x]['status'] == 'AVAILABLE'
                for x in ('player_stats', 'weekly_rosters', 'schedules'))}


def save_health(data_dir: Path, report: dict) -> Path:
    dest = Path(data_dir) / 'health.json'
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix('.json.tmp')
    tmp.write_text(json.dumps(report, indent=2), encoding='utf-8')
    tmp.replace(dest)
    return dest
