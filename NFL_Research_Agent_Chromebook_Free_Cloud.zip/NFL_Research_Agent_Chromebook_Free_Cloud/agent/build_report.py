"""Generate a time-aware NFL matchup research file from locally downloaded data."""
import argparse
import json
from pathlib import Path
from .game_research import from_disk, write_report


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data-dir", default="data")
    p.add_argument("--season", type=int, default=2026)
    p.add_argument("--week", type=int, default=6)
    p.add_argument("--away", default="WAS")
    p.add_argument("--home", default="SF")
    p.add_argument("--status-file", default="fixtures/statuses.json")
    args = p.parse_args()
    report = from_disk(Path(args.data_dir), args.season, args.week, args.away,
                       args.home, Path(args.status_file))
    target = write_report(Path(args.data_dir), report)
    print(json.dumps({"report": str(target), "warnings": report["warnings"],
                      "team_form": report["team_form"]}, indent=2))


if __name__ == "__main__":
    main()
