"""Cloud-friendly, read-only NFL research dashboard.

Reads small JSON summaries from GitHub without sharing raw parquet datasets,
credentials, or wagering data. Requires a public repository for live refreshes;
falls back to packaged local JSON when offline.
"""
from __future__ import annotations
import json
import re
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
import requests
import streamlit as st

DATA = Path('data')
MAX_JSON_BYTES = 6_000_000
st.set_page_config(page_title='NFL Research Monitor | 2026', page_icon='🏈', layout='wide')


def local_json(relative: str):
    path = DATA / relative
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None


@st.cache_data(ttl=900, show_spinner=False)
def remote_json(repository: str, relative: str):
    if not re.fullmatch(r'[a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+', repository):
        return None
    if not re.fullmatch(r'[a-zA-Z0-9_./-]+\.json', relative) or '..' in relative:
        return None
    url = f'https://raw.githubusercontent.com/{repository}/main/data/{relative}'
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        if len(response.content) > MAX_JSON_BYTES:
            return None
        return response.json()
    except (requests.RequestException, ValueError):
        return None


repo_metadata = local_json('repo.json') or {}
repo = repo_metadata.get('github_repository') or ''


def read_json(relative: str):
    return (remote_json(repo, relative) if repo else None) or local_json(relative)


st.title('🏈 NFL Research Monitor')
st.caption('Observed team performance • historical player workload • auditable data sources')
st.info('Research tool only. Displays observed statistics and data quality; no wagering recommendations.')

health = read_json('health.json') or {}
status = read_json('refresh_status.json') or {}
index = read_json('game_watchlist.json') or {}

stamp = status.get('refresh_finished_utc') or index.get('generated_utc')
if stamp:
    st.caption(f'Last attempted update (UTC): {stamp}')
else:
    st.warning('No dataset has been collected yet. Run the NFL research update workflow in GitHub Actions.')

col1, col2, col3 = st.columns(3)
with col1:
    st.metric('Upcoming game reports', len(index.get('games', [])))
with col2:
    feeds = health.get('feeds', {})
    st.metric('Available datasets', sum(x.get('status') == 'AVAILABLE' for x in feeds.values()))
with col3:
    st.metric('Primary data current', 'Yes' if health.get('ready_for_current_research') else 'No / unverified')

if repo:
    st.caption(f'Public repository: {repo} · latest summaries checked about every 15 minutes')
else:
    st.caption('Offline/local preview: public-repository updates are not connected yet.')

mode = st.radio('Explore', ['Upcoming games', 'Past player usage', 'Data quality'], horizontal=True)
choices = {f"{g.get('date','?')}: {g.get('away','?')} at {g.get('home','?')}": g
           for g in index.get('games', [])}

if mode == 'Data quality':
    for title, data in [('Dataset health', health),
                        ('Last retrieval attempt', status),
                        ('Schema validation', read_json('source_checks.json') or {}),
                        ('Report index', index)]:
        with st.expander(title, expanded=(title == 'Dataset health')):
            if data:
                st.json(data)
            else:
                st.warning('No report available for this section.')
else:
    if not choices:
        st.warning('No upcoming game reports available. Review Data quality or run the refresh workflow manually.')
        st.stop()
    key = st.selectbox('Choose matchup', list(choices.keys()))
    game = choices[key]
    report = read_json(game['file']) if game.get('file') else None
    if not report:
        st.warning('This game report could not be retrieved. Check GitHub Actions logs.')
        st.stop()
    st.caption(f"Season {report.get('season')} · Week {report.get('week')} · observations: {report.get('source_cutoff')}")
    for warning in report.get('warnings', []):
        st.warning(warning)
    if mode == 'Upcoming games':
        rows = []
        for team, team_data in report.get('team_form', {}).items():
            rows.append({'Team': team,
                         'Observed games': team_data.get('observed_games'),
                         **team_data.get('per_game_averages', {})})
        st.subheader('Observed prior game averages')
        if rows:
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
        else:
            st.info('No historical game averages for the selected matchup.')
        st.subheader('Published availability records')
        records = report.get('reported_availability', [])
        if records:
            st.dataframe(pd.DataFrame(records), use_container_width=True, hide_index=True)
        else:
            st.info('No verified injury statuses supplied. This does not mean that all players are available.')
    else:
        team = st.selectbox('Team', [report.get('away'), report.get('home')])
        players = report.get('player_usage', {}).get(team, [])
        st.subheader('Historical player workload')
        if players:
            records = [
                {'Player': x.get('player'), 'Position': x.get('position'),
                 'Observed games': x.get('games_observed'),
                 'Last observed week': x.get('last_observed_week'),
                 'Roster match': x.get('on_loaded_roster'),
                 **x.get('per_game_averages', {})}
                for x in players
            ]
            df = pd.DataFrame(records)
            st.dataframe(df, use_container_width=True, hide_index=True)
            changes = [{'Player': p.get('player'), **change}
                       for p in players
                       for change in p.get('observed_usage_changes', [])]
            if changes:
                st.subheader('Previously observed workload changes')
                st.dataframe(pd.DataFrame(changes), use_container_width=True, hide_index=True)
        else:
            st.info('No player history available for this team and game cutoff.')

st.divider()
st.caption('Source: nflverse/nflreadpy public data. Historical reports use only prior-game statistics. '
           'Schedules and rosters may lag official announcements; verify source timestamps.')
