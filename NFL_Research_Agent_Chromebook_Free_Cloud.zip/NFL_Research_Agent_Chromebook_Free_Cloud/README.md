# NFL Research Monitor — FREE Chromebook Cloud Edition

This project adapts Version 4 into a **no-terminal, browser-based hosting setup**:

- GitHub Actions runs NFL statistical downloads and integrity checks about **four times per day**.
- Successful public-data downloads are processed into small matchup summaries and JSON freshness reports.
- Only the summaries are committed to the GitHub repository; raw downloaded parquet files stay off Git.
- Streamlit Community Cloud displays the latest published JSON and source-quality warnings.
- The GitHub Actions scheduler runs in GitHub's cloud even if your Chromebook is switched off.

**Limits:** This is scheduled analysis, not a literally 24/7 compute process. GitHub cron can be delayed or skipped; free Streamlit apps hibernate when unused. No live sports feed has been tested in the authoring environment; the first hosted refresh must establish availability. This edition is a research monitor, not a validated predictive model.

## Chromebook deployment — NO Linux needed

1. Open https://github.com/login. Sign in, or choose "Create an account" for a free account.
2. Go to https://github.com/new. Repository name: `nfl-research-monitor-2026`. **Public** visibility is recommended for easiest no-cost setup and public dashboard data (do not upload any private information). Create the repository **without selecting an initial README**.
3. Download the project ZIP to the Chromebook. In ChromeOS **Files**, open the ZIP and copy the contents into a new folder in Downloads. Be sure to copy the **contents** of the folder, not the ZIP itself. If `.github` is hidden, use the Files app's show-hidden-files option.
4. Open your new GitHub repository. Choose **Add file → Upload files**. Drag in the extracted folder's **contents** (including `.github`, `agent`, `scripts`, `fixtures`, `streamlit_app.py`, `requirements.txt`, and other files). Click **Commit changes**. GitHub's browser upload supports folders.
5. On GitHub, select **Actions** → **NFL research update** → **Run workflow** → **Run workflow**. This first manual run downloads data and writes small dashboard JSON reports. Open its logs and look for test success and the commit message. If Actions are disabled, enable Actions for your repository under Settings. No account token or credit card is required.
6. Visit https://share.streamlit.io/. Sign in with GitHub → **Create app** → **Yup, I have an app**. Select repo `nfl-research-monitor-2026`, branch `main`, main file path **`streamlit_app.py`**, then **Deploy**.
7. Visit your new `.streamlit.app` link to see your NFL monitor. Free apps may go to sleep when unused; opening the link wakes them up. GitHub Actions can still refresh the data independently.

### If GitHub uploads miss the hidden `.github` folder

From your repo home, choose **Add file → Create new file** and type `.github/workflows/nfl-refresh.yml` as the file path. Copy the contents of that file from the project folder, then click **Commit changes**. The `Actions` tab will show the newly committed workflow.

### If GitHub Actions cannot push reports

The workflow explicitly requests **`contents: write`** permission. If the logs show `403` or `permission denied` when committing, check **Settings → Actions → General → Workflow permissions**. On an ordinary personal repository, enable the token to write repository contents if it is blocked. You do **not** need to share any GitHub password or token with ChatGPT.

### Check the first update

- GitHub **Actions** workflow run should show a green success state.
- `data/refresh_status.json` should exist with individual dataset status entries.
- `data/source_checks.json` should show whether player stats, rosters and schedules have valid schemas.
- `data/game_watchlist.json` should have upcoming fixtures **if the NFL schedule source downloaded correctly and games are scheduled in the next week**.
- Data health will say **No / unverified** unless the three necessary feeds are present and current.
- An empty injury file (`fixtures/statuses.json`) means no verified status records have been added, **not** that all players are healthy.

## Technical details

- Workflow: `.github/workflows/nfl-refresh.yml`, scheduled at 02:17, 08:17, 14:17, and 20:17 UTC.
- Worker: `python -m agent.worker --once`.
- Stored reports: `data/*.json` and `data/game_reports/*.json`.
- Dashboard: `streamlit_app.py`; checks latest JSON from `raw.githubusercontent.com` approximately every 15 minutes. Live GitHub access requires a **public** repository; private repos require a different authenticated design.
- Offline integrity checks: `python -m pytest -q`.
- To run locally: install both `requirements.txt` and `requirements-worker.txt`, then start `streamlit run streamlit_app.py`.
- Original V4 Docker collector and analysis modules are preserved for a future VM deployment.

The dashboard shows public historical sports statistics and data-quality reports; it does not access wagering platforms or compute betting value.
